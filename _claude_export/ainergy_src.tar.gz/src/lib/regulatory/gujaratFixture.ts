// Gujarat is not yet in the verified TARIFF_TABLE in tariffData.ts. Per the
// spec's testing requirements, it's kept as an explicitly placeholder-flagged
// fixture (used by the Prisma seed and by tests) rather than silently
// skipped or added to the verified table without a primary source.

import type { ConsumerType } from "./tariffData";

export const GUJARAT_PLACEHOLDER_TARIFF: Record<ConsumerType, number> = {
  commercial: 8.2,
  industrial: 7.2,
};
export const GUJARAT_PLACEHOLDER_CSS = 1.2;
export const GUJARAT_PLACEHOLDER_THRESHOLD_KVA = 1000;
export const GUJARAT_PLACEHOLDER_SOURCE = "Illustrative — verify before commercial use.";
