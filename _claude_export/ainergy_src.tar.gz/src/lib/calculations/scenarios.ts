// Scenario engine — promotes the mix categories already produced by
// computePlan() (rooftop / ground / wind / open access / grid shares) into
// six first-class, independently comparable procurement scenarios. Same
// rule-of-thumb discipline as optimizer.ts: deterministic, no LLM,
// illustrative constants, not engineering figures.

import { computePlan, type PlannerInputs, type PlannerResult } from "./optimizer";
import { WHEELING_BY_VOLTAGE } from "../regulatory/tariffData";

export type ScenarioStrategy =
  | "grid_only"
  | "third_party_oa"
  | "group_captive"
  | "solar_wind_hybrid"
  | "solar_bess"
  | "rooftop_oa";

export const SCENARIO_STRATEGIES: ScenarioStrategy[] = [
  "grid_only",
  "third_party_oa",
  "group_captive",
  "solar_wind_hybrid",
  "solar_bess",
  "rooftop_oa",
];

export const SCENARIO_LABELS: Record<ScenarioStrategy, string> = {
  grid_only: "Grid only",
  third_party_oa: "Third-party solar Open Access",
  group_captive: "Group captive solar",
  solar_wind_hybrid: "Solar + wind hybrid",
  solar_bess: "Solar + BESS",
  rooftop_oa: "Rooftop + Open Access",
};

// Illustrative 1 (low) – 5 (high) procurement/execution risk, not a
// regulatory or financial claim — reflects counterparty, structuring and
// asset-count complexity relative to the status quo.
export const SCENARIO_RISK_SCORE: Record<ScenarioStrategy, number> = {
  grid_only: 1,
  rooftop_oa: 2,
  solar_bess: 2,
  solar_wind_hybrid: 3,
  third_party_oa: 3,
  group_captive: 4,
};

export type ScenarioOutcome = {
  strategy: ScenarioStrategy;
  label: string;
  deliveredCostRsPerKwh: number;
  annualCostRs: number;
  annualSavingsRs: number;
  savingsPct: number;
  riskScore: number;
  eligible: boolean;
  plan: PlannerResult | null;
  /** Capex the Investment Path module should model for this scenario, or
   * null when the strategy has no owned/co-owned asset to finance (grid_only
   * has nothing to build; third_party_oa is a PPA, not an owned asset). */
  investableCapexRs: number | null;
};

// Captive generators are exempt from the cross-subsidy-surcharge portion of
// open-access charges under Rule 3 of the Electricity Rules 2005 (subject to
// the 26% equity / 51% consumption captive test) — approximated here as a
// deeper flat haircut off retail tariff than third-party OA gets. Same
// "flat discount off tariff" simplification optimizer.ts already uses for
// landedOpenAccessTariff; illustrative only, not a substitute for confirming
// actual captive eligibility and CSS treatment per state tariff order.
const THIRD_PARTY_LANDED_DISCOUNT = 0.18;
const CAPTIVE_LANDED_DISCOUNT = 0.23;

// Indicative self-owned generation LCOE, Rs/kWh — rule-of-thumb constants in
// the same spirit as optimizer.ts's CAPEX_RS_PER_KW, not engineering figures.
const ROOFTOP_SELF_COST_RS_PER_KWH = 3.6;
const GROUND_SELF_COST_RS_PER_KWH = 3.3;
const WIND_SELF_COST_RS_PER_KWH = 3.9;

const BESS_CAPEX_RS_PER_KWH = 20000; // indicative BESS capex, Rs per kWh of capacity
const BESS_LIFE_YEARS = 10;

// Group captive plants are typically remote (not built on the consumer's own
// site), so there's no rooftop/ground area to size against here — capex is
// approximated as the member's proportional stake, sized off the kW served
// through the captive route, at a blended ground-mount-ish rate.
const CAPTIVE_CAPEX_RS_PER_KW = 40000;

function landedTariff(
  tariff: number,
  voltageLevel: PlannerInputs["voltageLevel"],
  discount: number
): number {
  const { chargeRsPerKwh } = WHEELING_BY_VOLTAGE[voltageLevel];
  return Math.round((tariff * (1 - discount) + chargeRsPerKwh) * 100) / 100;
}

function blendedDeliveredCost(
  plan: PlannerResult,
  tariff: number,
  voltageLevel: PlannerInputs["voltageLevel"],
  oaDiscount: number
): number {
  const oaRate = landedTariff(tariff, voltageLevel, oaDiscount);
  const weighted =
    (plan.rooftopSharePct / 100) * ROOFTOP_SELF_COST_RS_PER_KWH +
    (plan.groundSharePct / 100) * GROUND_SELF_COST_RS_PER_KWH +
    (plan.windSharePct / 100) * WIND_SELF_COST_RS_PER_KWH +
    (plan.openAccessSharePct / 100) * oaRate +
    (plan.gridSharePct / 100) * tariff;
  return Math.round(weighted * 100) / 100;
}

function bessSurchargeRsPerKwh(batteryKwh: number, annualConsumptionKwh: number): number {
  if (annualConsumptionKwh <= 0) return 0;
  const annualizedCapex = (batteryKwh * BESS_CAPEX_RS_PER_KWH) / BESS_LIFE_YEARS;
  return annualizedCapex / annualConsumptionKwh;
}

function outcome(
  strategy: ScenarioStrategy,
  base: PlannerInputs,
  deliveredCostRsPerKwh: number,
  gridOnlyAnnualCostRs: number,
  eligible: boolean,
  plan: PlannerResult | null,
  investableCapexRs: number | null = null
): ScenarioOutcome {
  const annualCostRs = Math.round(deliveredCostRsPerKwh * base.consumption * 12);
  const annualSavingsRs = Math.round(gridOnlyAnnualCostRs - annualCostRs);
  const savingsPct =
    gridOnlyAnnualCostRs > 0 ? Math.round((annualSavingsRs / gridOnlyAnnualCostRs) * 1000) / 10 : 0;
  return {
    strategy,
    label: SCENARIO_LABELS[strategy],
    deliveredCostRsPerKwh,
    annualCostRs,
    annualSavingsRs,
    savingsPct,
    riskScore: SCENARIO_RISK_SCORE[strategy],
    eligible,
    plan,
    investableCapexRs,
  };
}

/**
 * Computes all six procurement scenarios for a consumption profile. Each
 * non-grid scenario targets 100% renewable replacement (rather than the
 * user's chosen target %) so scenarios show each strategy's economics at its
 * own ceiling — useful for comparison, distinct from the single blended plan
 * `/energy-optimizer` shows for one user-chosen target %.
 */
export function buildScenarios(base: PlannerInputs): ScenarioOutcome[] {
  const gridOnlyAnnualCostRs = Math.round(base.tariff * base.consumption * 12);

  const results: ScenarioOutcome[] = [];

  results.push(outcome("grid_only", base, base.tariff, gridOnlyAnnualCostRs, true, null));

  const thirdPartyInputs: PlannerInputs = {
    ...base,
    renewableTarget: 100,
    rooftopArea: 0,
    groundArea: 0,
    considerGround: false,
    considerWind: false,
    includeOpenAccess: true,
  };
  const thirdPartyPlan = computePlan(thirdPartyInputs);
  results.push(
    outcome(
      "third_party_oa",
      base,
      thirdPartyPlan.achievedRenewablePct > 0
        ? blendedDeliveredCost(thirdPartyPlan, base.tariff, base.voltageLevel, THIRD_PARTY_LANDED_DISCOUNT)
        : base.tariff,
      gridOnlyAnnualCostRs,
      thirdPartyPlan.openAccessEligible,
      thirdPartyPlan
    )
  );

  const captivePlan = thirdPartyPlan; // same sizing/eligibility, different discount
  results.push(
    outcome(
      "group_captive",
      base,
      captivePlan.achievedRenewablePct > 0
        ? blendedDeliveredCost(captivePlan, base.tariff, base.voltageLevel, CAPTIVE_LANDED_DISCOUNT)
        : base.tariff,
      gridOnlyAnnualCostRs,
      captivePlan.openAccessEligible,
      captivePlan,
      captivePlan.openAccessKw > 0 ? Math.round(captivePlan.openAccessKw * CAPTIVE_CAPEX_RS_PER_KW) : null
    )
  );

  const hybridInputs: PlannerInputs = {
    ...base,
    renewableTarget: 100,
    considerGround: true,
    considerWind: true,
    includeOpenAccess: true,
  };
  const hybridPlan = computePlan(hybridInputs);
  results.push(
    outcome(
      "solar_wind_hybrid",
      base,
      blendedDeliveredCost(hybridPlan, base.tariff, base.voltageLevel, THIRD_PARTY_LANDED_DISCOUNT),
      gridOnlyAnnualCostRs,
      true,
      hybridPlan,
      hybridPlan.projectCostEstimateRs > 0 ? hybridPlan.projectCostEstimateRs : null
    )
  );

  const bessInputs: PlannerInputs = {
    ...base,
    renewableTarget: 100,
    groundArea: 0,
    considerGround: false,
    considerWind: false,
    includeOpenAccess: false,
  };
  const bessPlan = computePlan(bessInputs);
  const bessBase = blendedDeliveredCost(bessPlan, base.tariff, base.voltageLevel, THIRD_PARTY_LANDED_DISCOUNT);
  const bessSurcharge = bessSurchargeRsPerKwh(bessPlan.batteryKwh, base.consumption * 12);
  results.push(
    outcome(
      "solar_bess",
      base,
      Math.round((bessBase + bessSurcharge) * 100) / 100,
      gridOnlyAnnualCostRs,
      true,
      bessPlan,
      bessPlan.projectCostEstimateRs + bessPlan.batteryKwh * BESS_CAPEX_RS_PER_KWH
    )
  );

  const rooftopOaInputs: PlannerInputs = {
    ...base,
    renewableTarget: 100,
    groundArea: 0,
    considerGround: false,
    considerWind: false,
    includeOpenAccess: true,
  };
  const rooftopOaPlan = computePlan(rooftopOaInputs);
  results.push(
    outcome(
      "rooftop_oa",
      base,
      blendedDeliveredCost(rooftopOaPlan, base.tariff, base.voltageLevel, THIRD_PARTY_LANDED_DISCOUNT),
      gridOnlyAnnualCostRs,
      true,
      rooftopOaPlan,
      rooftopOaPlan.projectCostEstimateRs > 0 ? rooftopOaPlan.projectCostEstimateRs : null
    )
  );

  return results;
}

export function rankScenarios(outcomes: ScenarioOutcome[]): ScenarioOutcome[] {
  return [...outcomes].sort((a, b) => a.deliveredCostRsPerKwh - b.deliveredCostRsPerKwh);
}
