import type { ReactNode } from "react";
import Link from "next/link";
import { Container } from "@/components/ui/Container";
import { requireSession } from "@/lib/auth/session";
import { SignOutButton } from "@/components/auth/SignOutButton";

const IN_APP_LINKS = [
  { label: "Dashboard", href: "/dashboard" },
  { label: "Facilities", href: "/facilities" },
  { label: "Settings", href: "/settings" },
];

export default async function AppLayout({ children }: { children: ReactNode }) {
  const session = await requireSession();

  return (
    <div className="min-h-screen bg-graphite-950 pt-20">
      <div className="border-b border-white/10 bg-graphite-900/60">
        <Container className="flex h-14 items-center justify-between">
          <div className="flex items-center gap-6">
            {IN_APP_LINKS.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="text-sm text-offwhite-300/70 transition-colors hover:text-offwhite-100"
              >
                {link.label}
              </Link>
            ))}
          </div>
          <div className="flex items-center gap-4 text-sm text-offwhite-300/60">
            <span>{session.user.email}</span>
            <SignOutButton />
          </div>
        </Container>
      </div>
      {children}
    </div>
  );
}
