import Link from "next/link";
import { Plus, Factory } from "lucide-react";
import { Container } from "@/components/ui/Container";
import { SectionHeader } from "@/components/ui/SectionHeader";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/auth/session";

export default async function FacilitiesPage() {
  const session = await requireSession();

  const facilities = await db.facility.findMany({
    where: { organizationId: session.user.organizationId },
    orderBy: { createdAt: "desc" },
    include: { _count: { select: { consumptionProfiles: true } } },
  });

  return (
    <section className="py-16 lg:py-20">
      <Container>
        <div className="flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between">
          <SectionHeader
            eyebrow="Facilities"
            title="Your facilities"
            description="Each facility carries its own load profile, tariff and Open Access analysis."
          />
          <Link
            href="/facilities/new"
            className="inline-flex shrink-0 items-center justify-center gap-2 rounded-full bg-emerald-500 px-6 py-3 text-sm font-medium text-graphite-950 transition-all hover:bg-emerald-400 hover:shadow-glow"
          >
            <Plus className="h-4 w-4" />
            New facility
          </Link>
        </div>

        {facilities.length === 0 ? (
          <div className="mt-10 rounded-3xl border border-white/10 bg-graphite-900/40 p-12 text-center">
            <Factory className="mx-auto h-8 w-8 text-offwhite-300/40" />
            <p className="mt-4 text-sm text-offwhite-300/60">
              No facilities yet. Add one to start an Open Access analysis.
            </p>
          </div>
        ) : (
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {facilities.map((facility) => (
              <Link
                key={facility.id}
                href={`/facilities/${facility.id}`}
                className="rounded-2xl border border-white/10 bg-graphite-900/40 p-6 transition-colors hover:border-teal-400/40"
              >
                <p className="font-display text-lg font-medium text-offwhite-100">{facility.name}</p>
                <p className="mt-1 text-sm text-offwhite-300/60">
                  {facility.state} · {facility.consumerType} · {facility.voltageLevel}
                </p>
                <p className="mt-3 text-xs text-offwhite-300/45">
                  {facility.sanctionedLoadKva.toLocaleString("en-IN")} kVA sanctioned
                </p>
                <p className="mt-1 text-xs text-offwhite-300/45">
                  {facility._count.consumptionProfiles === 0
                    ? "No consumption profile yet"
                    : `${facility._count.consumptionProfiles} consumption profile(s)`}
                </p>
              </Link>
            ))}
          </div>
        )}
      </Container>
    </section>
  );
}
